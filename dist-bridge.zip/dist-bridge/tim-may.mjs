#!/usr/bin/env node

// tools/attendance-find.mjs
import { execFile } from "node:child_process";
import net2 from "node:net";
import os from "node:os";
import { promisify } from "node:util";

// node_modules/.pnpm/zkteco-protocol@0.6.1/node_modules/zkteco-protocol/dist/index.js
import net from "net";
import dgram from "dgram";
var CMD = {
  CONNECT: 1e3,
  EXIT: 1001,
  ENABLEDEVICE: 1002,
  DISABLEDEVICE: 1003,
  AUTH: 1102,
  OPTIONS_RRQ: 11,
  GET_TIME: 201,
  GET_VERSION: 1100,
  REG_EVENT: 500,
  GET_FREE_SIZES: 50,
  ATTLOG_RRQ: 13,
  USERTEMP_RRQ: 9,
  PREPARE_DATA: 1500,
  DATA: 1501,
  FREE_DATA: 1502,
  PREPARE_BUFFER: 1503,
  READ_BUFFER: 1504,
  ACK_OK: 2e3,
  ACK_ERROR: 2001,
  ACK_DATA: 2002,
  ACK_UNAUTH: 2005
};
var MAX_CHUNK = { tcp: 65472, udp: 16 * 1024 };
var BUFFER_FCT = {
  [CMD.USERTEMP_RRQ]: 5,
  [CMD.ATTLOG_RRQ]: 0
};
var ZkError = class extends Error {
  /** Hex of the bytes that caused this error, when any exist. */
  raw;
  constructor(message, raw) {
    super(message);
    this.name = new.target.name;
    if (raw) this.raw = raw.toString("hex");
  }
};
var ZkConnectionError = class extends ZkError {
};
var ZkTimeoutError = class extends ZkError {
};
var ZkAuthError = class extends ZkError {
};
var ZkProtocolError = class extends ZkError {
};
var ZkFramingError = class extends ZkError {
};
var pad = (n, width = 2) => String(n).padStart(width, "0");
function make(year, month, day, hour, minute, second) {
  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    local: `${pad(year, 4)}-${pad(month)}-${pad(day)}T${pad(hour)}:${pad(minute)}:${pad(second)}`
  };
}
function decodeZkTime(t) {
  let v = t >>> 0;
  const second = v % 60;
  v = Math.floor(v / 60);
  const minute = v % 60;
  v = Math.floor(v / 60);
  const hour = v % 24;
  v = Math.floor(v / 24);
  const day = v % 31 + 1;
  v = Math.floor(v / 31);
  const month = v % 12 + 1;
  v = Math.floor(v / 12);
  return make(v + 2e3, month, day, hour, minute, second);
}
function decodeZkTime6(buf, offset = 0) {
  if (offset < 0 || buf.length < offset + 6) {
    throw new ZkProtocolError(
      `decodeZkTime6 needs 6 bytes at offset ${offset}, buffer has ${buf.length}`,
      buf
    );
  }
  return make(
    2e3 + buf[offset],
    buf[offset + 1],
    buf[offset + 2],
    buf[offset + 3],
    buf[offset + 4],
    buf[offset + 5]
  );
}
function readNulTerminated(buf, start, length) {
  const field = buf.subarray(start, start + length);
  const end = field.indexOf(0);
  return field.subarray(0, end === -1 ? field.length : end).toString("latin1");
}
var KNOWN_SIZES = [8, 16, 40];
var JUNK_PREFIX = Buffer.from([255, 50, 53, 53, 0, 0, 0, 0, 0]);
function mapStatusAndVerify(recordStatus, recordPunch) {
  return { status: recordStatus, verifyMode: recordPunch };
}
function detectRecordSize(bodyLength, recordCount) {
  if (!Number.isInteger(recordCount) || recordCount <= 0) {
    throw new ZkFramingError(`record count must be a positive integer, got ${recordCount}`);
  }
  if (bodyLength % recordCount !== 0) {
    throw new ZkFramingError(
      `record body of ${bodyLength} bytes does not divide evenly by ${recordCount} records`
    );
  }
  const size = bodyLength / recordCount;
  if (!KNOWN_SIZES.includes(size)) {
    throw new ZkFramingError(
      `derived record size ${size} is not one of ${KNOWN_SIZES.join(", ")}`
    );
  }
  return size;
}
function decodeOne(rec, size) {
  const raw = rec.toString("hex");
  if (size === 40) {
    const { status: status2, verifyMode: verifyMode2 } = mapStatusAndVerify(rec.readUInt8(26), rec.readUInt8(31));
    const printedUserId = readNulTerminated(rec, 2, 24);
    return {
      uid: rec.readUInt16LE(0),
      // A blank field must not be reported as a device-supplied identity —
      // '' labelled userIdSource: 'device' is exactly the fabricated
      // identity the public API promises never to hand back (README,
      // spec §4.2). null instead lets this record flow into the same
      // lookup-by-uid path as the 8- and 16-byte dialects.
      userIdFromRecord: printedUserId === "" ? null : printedUserId,
      numericUserId: null,
      timestamp: decodeZkTime(rec.readUInt32LE(27)),
      status: status2,
      verifyMode: verifyMode2,
      recordSize: 40,
      raw
    };
  }
  if (size === 16) {
    const { status: status2, verifyMode: verifyMode2 } = mapStatusAndVerify(rec.readUInt8(8), rec.readUInt8(9));
    return {
      uid: null,
      userIdFromRecord: null,
      // Rendering this as a string would strip leading zeros and lose the
      // identity. Resolve it through the user list instead.
      numericUserId: rec.readUInt32LE(0),
      timestamp: decodeZkTime(rec.readUInt32LE(4)),
      status: status2,
      verifyMode: verifyMode2,
      recordSize: 16,
      raw
    };
  }
  const { status, verifyMode } = mapStatusAndVerify(rec.readUInt8(2), rec.readUInt8(7));
  return {
    uid: rec.readUInt16LE(0),
    userIdFromRecord: null,
    numericUserId: null,
    timestamp: decodeZkTime(rec.readUInt32LE(3)),
    status,
    verifyMode,
    recordSize: 8,
    raw
  };
}
function parseAttendanceData(data, recordCount) {
  if (recordCount === 0) return [];
  if (data.length < 4) {
    throw new ZkFramingError("attendance payload too short to hold its size header", data);
  }
  const totalSize = data.readUInt32LE(0);
  if (data.length < 4 + totalSize) {
    throw new ZkFramingError(
      `attendance payload declares ${totalSize} bytes but only ${data.length - 4} arrived`,
      data.subarray(0, 16)
    );
  }
  let body = data.subarray(4, 4 + totalSize);
  if (body.subarray(0, JUNK_PREFIX.length).equals(JUNK_PREFIX)) {
    body = body.subarray(JUNK_PREFIX.length);
  }
  const size = detectRecordSize(body.length, recordCount);
  const out = [];
  for (let off = 0; off + size <= body.length; off += size) {
    out.push(decodeOne(body.subarray(off, off + size), size));
  }
  return out;
}
function checksum16(payload) {
  let sum = 0;
  for (let i = 0; i < payload.length; i += 2) {
    if (i === 2) continue;
    sum += i + 1 < payload.length ? payload.readUInt16LE(i) : payload[i];
  }
  while (sum >>> 16) sum = (sum & 65535) + (sum >>> 16);
  return ~sum & 65535;
}
var HEADER_SIZE = 8;
var EMPTY = Buffer.alloc(0);
function encodePayload({ command, sessionId, replyId, data = EMPTY }) {
  const buf = Buffer.alloc(HEADER_SIZE + data.length);
  buf.writeUInt16LE(command & 65535, 0);
  buf.writeUInt16LE(0, 2);
  buf.writeUInt16LE(sessionId & 65535, 4);
  buf.writeUInt16LE(replyId & 65535, 6);
  data.copy(buf, HEADER_SIZE);
  buf.writeUInt16LE(checksum16(buf), 2);
  return buf;
}
function decodePayload(buf) {
  if (buf.length < HEADER_SIZE) {
    throw new ZkProtocolError(`payload shorter than the ${HEADER_SIZE}-byte header`, buf);
  }
  return {
    command: buf.readUInt16LE(0),
    checksum: buf.readUInt16LE(2),
    sessionId: buf.readUInt16LE(4),
    replyId: buf.readUInt16LE(6),
    data: Buffer.from(buf.subarray(HEADER_SIZE))
  };
}
var XOR_TAG = [90, 75, 83, 79];
var DEFAULT_TICKS = 50;
function mixCommKey(commKey, sessionId, ticks = DEFAULT_TICKS) {
  let k = 0;
  for (let i = 0; i < 32; i++) {
    k = (k << 1 | commKey >>> i & 1) >>> 0;
  }
  k = k + (sessionId >>> 0) >>> 0;
  const packed = Buffer.alloc(4);
  packed.writeUInt32LE(k, 0);
  for (let i = 0; i < 4; i++) {
    packed[i] = packed[i] ^ XOR_TAG[i];
  }
  const out = Buffer.from([packed[2], packed[3], packed[0], packed[1]]);
  const b = ticks & 255;
  out[0] = out[0] ^ b;
  out[1] = out[1] ^ b;
  out[2] = b;
  out[3] = out[3] ^ b;
  return out;
}
var EVENT_FLAG = {
  ATTENDANCE: 1,
  FINGER: 2,
  ENROLL_USER: 4,
  ENROLL_FINGER: 8,
  BUTTON: 16,
  UNLOCK: 32,
  VERIFY: 128,
  FPFTR: 256,
  ALARM: 512
};
function encodeEventMask(mask) {
  const buf = Buffer.alloc(4);
  buf.writeUInt32LE(mask >>> 0, 0);
  return buf;
}
function isEventPacket(pkt) {
  return pkt.command === CMD.REG_EVENT;
}
function readEventType(pkt) {
  return pkt.sessionId;
}
var LARGE_MIN_LENGTH = 32;
var SMALL_LENGTH = 10;
var PRINTED_ID_LENGTH = 9;
var PRINTED_ID_OFFSET = 0;
var VERIFY_MODE_OFFSET = 24;
var LARGE_TIME_OFFSET = 26;
var SMALL_UID_OFFSET = 0;
var SMALL_TIME_OFFSET = 4;
function readPrintableId(buf, start, length) {
  const field = buf.subarray(start, start + length);
  const nul = field.indexOf(0);
  const body = field.subarray(0, nul === -1 ? field.length : nul);
  if (body.length === 0) return null;
  for (const byte of body) {
    if (byte < 32 || byte > 126) return null;
  }
  return body.toString("ascii");
}
function decodeRealtimeAttendance(data) {
  if (data.length >= LARGE_MIN_LENGTH) {
    return {
      userId: readPrintableId(data, PRINTED_ID_OFFSET, PRINTED_ID_LENGTH),
      uid: null,
      verifyMode: data.readUInt16LE(VERIFY_MODE_OFFSET),
      timestamp: decodeZkTime6(data, LARGE_TIME_OFFSET)
    };
  }
  if (data.length === SMALL_LENGTH) {
    return {
      userId: null,
      uid: data.readUInt8(SMALL_UID_OFFSET),
      verifyMode: null,
      timestamp: decodeZkTime6(data, SMALL_TIME_OFFSET)
    };
  }
  return null;
}
function decodeRealtimeEvent(pkt) {
  const eventType = readEventType(pkt);
  const raw = pkt.data.toString("hex");
  if (eventType !== EVENT_FLAG.ATTENDANCE) return { kind: "unknown", eventType, raw };
  const decoded = decodeRealtimeAttendance(pkt.data);
  if (!decoded) return { kind: "unknown", eventType, raw };
  return {
    kind: "attendance",
    eventType,
    userId: decoded.userId,
    userIdSource: decoded.userId === null ? null : "device",
    uid: decoded.uid,
    timestamp: decoded.timestamp,
    verifyMode: decoded.verifyMode,
    raw
  };
}
function unauthorizedReply(command, data) {
  return new ZkAuthError(
    `command ${command} answered ACK_UNAUTH: the device did not authorize this request`,
    data
  );
}
var Session = class {
  constructor(transport, opts) {
    this.transport = transport;
    this.opts = opts;
  }
  transport;
  opts;
  currentSessionId = 0;
  replyId = 0;
  open_ = false;
  subscribed_ = false;
  get sessionId() {
    return this.currentSessionId;
  }
  /** True once this session has switched its transport to listening. */
  get subscribed() {
    return this.subscribed_;
  }
  /**
   * Handshakes and stores the session id the device issues.
   *
   * If the device answers CONNECT with ACK_UNAUTH, it is demanding a comm
   * key: the configured key is mixed against the session id it just issued
   * (per `mixCommKey`) and sent back as CMD_AUTH. No key configured, or a
   * key the device rejects, both surface as ZkAuthError.
   *
   * On any failure — refused handshake, rejected/missing comm key, or
   * timeout — the transport is torn down before the error propagates.
   * Nothing above this call ever manages to close a session that never
   * finished opening, so leaving that to the caller would leak the socket.
   */
  async open() {
    await this.transport.connect(this.opts.timeoutMs);
    this.open_ = true;
    try {
      const res = await this.send(CMD.CONNECT, void 0, { sessionId: 0 });
      if (res.command === CMD.ACK_UNAUTH) {
        const commKey = this.opts.commKey ?? 0;
        if (commKey === 0) {
          throw new ZkAuthError("device requires a comm key but none was configured");
        }
        this.currentSessionId = res.sessionId;
        const auth = await this.send(CMD.AUTH, mixCommKey(commKey, res.sessionId));
        if (auth.command !== CMD.ACK_OK) {
          throw new ZkAuthError("device rejected the comm key");
        }
        this.currentSessionId = auth.sessionId;
        return;
      }
      if (res.command !== CMD.ACK_OK) {
        throw new ZkProtocolError(`handshake refused with command ${res.command}`);
      }
      this.currentSessionId = res.sessionId;
    } catch (err) {
      this.open_ = false;
      await this.transport.close().catch(() => {
      });
      throw err;
    }
  }
  /**
   * Sends one command and returns the reply, ACK_ERROR included.
   *
   * For call sites where a device refusing the command is a normal answer
   * rather than a failure — reading a parameter keyword a firmware does not
   * expose, for instance. The alternative, catching ZkProtocolError around
   * execute(), would also swallow a genuine protocol error raised anywhere
   * below and turn it into a "the device said no". That is the defect shape
   * this project has caught nine times in v0.1 and again in v0.2: code that
   * reports success while proving less than it appears to.
   *
   * Only ACK_ERROR becomes readable here. A timeout, a dropped connection and
   * a malformed packet all still propagate.
   */
  async tryExecute(command, data) {
    this.assertOpen();
    return this.send(command, data);
  }
  /**
   * Sends one command and returns the reply.
   *
   * Throws on exactly two reply codes: ACK_ERROR as ZkProtocolError, and
   * ACK_UNAUTH as ZkAuthError. Every other reply is returned for the caller
   * to decode.
   *
   * ACK_UNAUTH acknowledges NOTHING, and every read in this library would
   * otherwise decode its body as an answer: getInfo() reads storage counters
   * out of any body of 68 bytes or more, decodeZkTime() turns any four bytes
   * into a plausible date, and readBulkBuffered() takes bytes 1-4 of a
   * five-byte PREPARE_BUFFER reply as a transfer size. The guard lives here
   * rather than at each call site because the bulk reads reach the device
   * through readBulk()'s internals -- READ_BUFFER, FREE_DATA -- where there
   * is no call site to guard, and because a rule kept in six places drifts.
   * readBulkBuffered()'s own PREPARE_BUFFER call is the one exception: it
   * calls tryExecute() and raises ACK_UNAUTH itself, through the
   * `unauthorizedReply` helper above (same wording, one definition), because
   * it is the one tryExecute caller that must not inherit readBulk()'s
   * catch-based fallback to the legacy path (spec v0.5 §6.2).
   *
   * open() and subscribe() use the private send() directly and are
   * deliberately unaffected: the comm-key handshake must keep reading
   * ACK_UNAUTH as the demand for a key that it is.
   *
   * ZkAuthError rather than ZkProtocolError, and the class carries weight
   * beyond naming. readBulk() falls back from the buffered commands to the
   * legacy exchange on exactly `err instanceof ZkProtocolError`, so an
   * ACK_UNAUTH classed as a protocol error is read as "this firmware does
   * not implement 1503" -- an authentication failure reported as a firmware
   * capability, and then retried down a path whose answer cannot be trusted,
   * because whatever comes back was produced after the device said this
   * session was not authorized. As a sibling class under ZkError it
   * propagates instead, which is what that path needs.
   *
   * Only ACK_UNAUTH is singled out. Tightening this to "only ACK_OK counts
   * as success" is deliberately NOT done: nothing confirms real firmware
   * acknowledges these commands with ACK_OK rather than, say, ACK_DATA, and
   * inventing that constraint would be exactly the kind of unevidenced
   * hypothesis this project avoids.
   */
  async execute(command, data) {
    const res = await this.tryExecute(command, data);
    if (res.command === CMD.ACK_ERROR) {
      throw new ZkProtocolError(`device rejected command ${command}`);
    }
    if (res.command === CMD.ACK_UNAUTH) {
      throw unauthorizedReply(command, res.data);
    }
    return res;
  }
  /**
   * Registers for realtime events and switches the transport to listening.
   *
   * The registration itself is an ordinary request-response exchange, which
   * is why it runs before the mode flip and over the same socket. A refused
   * registration throws and leaves the session in request mode: firmware
   * without realtime support costs one call, not the connection.
   *
   * A DESYNCED registration is treated differently, and the asymmetry is
   * deliberate. If the device pushes an event in the window between reading
   * this request and writing its ack, that event consumes the pending waiter
   * and the real ACK_OK is stranded in the transport queue — where the NEXT
   * request would collect it as its own reply, and every reply after that
   * would be off by one. A refusal leaves nothing out of step, so the session
   * stays usable (design spec §3.4); a desync makes every later reply
   * silently wrong, which is the exact misroute §3.1 rejected the
   * multiplexing design to avoid. So the session is torn down here, before
   * the error propagates, and cannot be polled afterwards -- enforced by
   * `assertOpen` on this class's own request path, not left to the socket
   * being gone, which is where that guarantee used to actually live.
   *
   * Buffering the early event and replaying it onto the stream was considered
   * and rejected (RULING R11). It would preserve the punch, but only by
   * building a bounded version of that same router, resting on a
   * discrimination rule no device has ever confirmed. Spec §1.1 already
   * answers a lost event: polling is the source of truth, and the next poll
   * recovers it.
   *
   * Guarded before anything is sent: a second subscribe() used to transmit a
   * second REG_EVENT whose acknowledgment then arrived on the listening
   * socket and ended the live stream as "a non-event packet", blaming the
   * device.
   */
  async subscribe(mask, onPacket, onError) {
    this.assertOpen();
    if (this.subscribed_) {
      throw new ZkConnectionError(
        "this session is already subscribed to realtime events; close it and reconnect to subscribe again"
      );
    }
    const res = await this.send(CMD.REG_EVENT, encodeEventMask(mask));
    if (isEventPacket(res)) {
      await this.abandon();
      throw new ZkProtocolError(
        "a realtime event arrived where the CMD_REG_EVENT reply was expected: the device pushed an event before acknowledging the registration, so the reply stream is out of step. This session has been torn down; reconnect before using it again"
      );
    }
    if (res.command === CMD.ACK_UNAUTH) {
      throw new ZkAuthError(
        "CMD_REG_EVENT answered ACK_UNAUTH: the device did not authorize a realtime subscription",
        res.data
      );
    }
    if (res.command !== CMD.ACK_OK) {
      throw new ZkProtocolError(
        `device refused a realtime subscription with command ${res.command}`
      );
    }
    this.subscribed_ = true;
    this.transport.listen((payload) => {
      try {
        onPacket(decodePayload(payload));
      } catch (err) {
        onError(err);
      }
    }, onError);
  }
  /** Encodes and transmits one request without awaiting a reply. */
  async transmit(command, data, override) {
    const sessionId = override?.sessionId ?? this.currentSessionId;
    const payload = encodePayload({ command, sessionId, replyId: this.replyId, data });
    this.replyId = this.replyId + 1 & 65535;
    await this.transport.send(payload);
  }
  inFlight = false;
  /**
   * Runs one transmit-and-receive with at most one in flight per session.
   *
   * Refused BEFORE anything is transmitted. Until v0.5 both requests went on
   * the wire and only the second receive() was refused, so the first caller
   * collected whichever reply came first and the other reply sat in the
   * queue for the next request (review R1, second half).
   */
  async exchange(fn) {
    if (this.subscribed_) {
      throw new ZkConnectionError(
        "this session is subscribed to realtime events and cannot make requests; close the stream and reconnect to read"
      );
    }
    if (this.inFlight) {
      throw new ZkConnectionError(
        "a request is already in flight on this session; issue one at a time"
      );
    }
    this.inFlight = true;
    try {
      return await fn();
    } catch (err) {
      if (err instanceof ZkTimeoutError || err instanceof ZkFramingError || err instanceof ZkConnectionError) {
        await this.abandon();
      }
      throw err;
    } finally {
      this.inFlight = false;
    }
  }
  /**
   * Encodes and transmits one request, then awaits its reply.
   *
   * Transmits the packet exactly as encoded: no reply-id quirk. The spec
   * asserted that the transmitted reply id runs one ahead of the one its
   * checksum covers, but oracle evidence contradicts it — pyzk and
   * zkteco-js, driven against the emulator as black boxes on both TCP and
   * UDP, both emit checksums that match the reply id they actually carry,
   * never `replyId - 1`, even though the two libraries start their reply-id
   * counters at different values (0 and 1). `applyReplyIdQuirk` stays
   * exported and tested in src/codec/packet.ts, one call site away, in case
   * a real device turns out to need it.
   */
  send(command, data, override) {
    return this.exchange(async () => {
      await this.transmit(command, data, override);
      return decodePayload(await this.transport.receive(this.opts.timeoutMs));
    });
  }
  /**
   * Receives one further packet in an ongoing multi-packet exchange.
   *
   * Guarded like `tryExecute` rather than left to the transport: this path
   * sends nothing, so a torn-down session reaching it would be collecting
   * packets belonging to an exchange that no longer has an owner.
   */
  async receiveMore() {
    this.assertOpen();
    return this.exchange(async () => decodePayload(await this.transport.receive(this.opts.timeoutMs)));
  }
  /**
   * Refuses a request from a session that is no longer open.
   *
   * The guarantee `subscribe` promises used to be delivered one layer down:
   * `abandon` set `open_ = false` and closed the socket, nothing on the
   * request path ever read `open_`, and what actually refused the next call
   * was the destroyed socket. That worked, and it was untestable -- against a
   * real transport a ZkConnectionError from the guard and one from the socket
   * are indistinguishable, so the docblock's claim rested on a mechanism no
   * test could pin. It also meant a transport that queued, reconnected, or
   * simply had not noticed the close yet would answer, and the reply would be
   * the one this session's teardown existed to stop being read.
   *
   * ZkConnectionError, deliberately: the class callers already handle for a
   * session they can no longer use. Only the message changes, naming this
   * layer as the refuser.
   *
   * Applied to the public request path, NOT to `send`. `close` sets `open_`
   * false and then sends its goodbye through `send`, and on UDP that goodbye
   * is the only thing telling the device to release the session slot.
   */
  assertOpen() {
    if (this.open_) return;
    throw new ZkConnectionError(
      "this session is not open: it was closed, or torn down after its reply stream went out of step. Reconnect before using it again"
    );
  }
  /**
   * Ends a session whose reply stream can no longer be trusted.
   *
   * No reply is awaited for the goodbye: the next packet to arrive belongs to
   * some earlier exchange, so reading one would only deepen the confusion.
   * The same is true of a subscribed session — the socket is listening, so a
   * reply could never be read there either — which is why close() defers to
   * this method rather than duplicating it. The goodbye is still sent — on
   * UDP there is no connection close to tell the device the session is over,
   * so skipping it would leave the device holding the session slot. Nothing
   * here throws; the caller is already on its way to reporting a failure of
   * its own.
   *
   * Sent where a socket still exists, which is not everywhere this runs. A
   * framing failure destroys the transport as it rejects the frame (§4.5), so
   * the EXIT has nothing to write to and the swallowed rejection is the whole
   * of it — `test/session/session.spec.ts`'s framing test records the
   * emulator receiving CONNECT and GET_FREE_SIZES and no EXIT. Where the
   * goodbye does reach the device, a test says so rather than a comment: the
   * timeout teardown (`session.spec.ts`, "closes the session on a timeout"),
   * a UDP connection error whose socket outlived it (same file, "releases the
   * transport socket"), and close() of a subscribed session
   * (`test/realtime/scenarios.spec.ts`).
   */
  async abandon() {
    if (!this.open_) return;
    this.open_ = false;
    this.subscribed_ = false;
    await this.transmit(CMD.EXIT).catch(() => {
    });
    await this.transport.close().catch(() => {
    });
  }
  /**
   * Ends the session. Never throws: a goodbye is best effort, and a device
   * that has already gone away needs none.
   *
   * A subscribed session cannot read a reply — the socket is listening — so
   * it goes through abandon(), which sends EXIT without awaiting one. On UDP
   * that goodbye is the only thing telling the device to release the session
   * slot, which is why it is sent at all. A goodbye that times out does NOT
   * run the §5.2 teardown, despite reaching its catch: `open_` was cleared on
   * the line above, so `abandon()` returns immediately and tears nothing
   * down. The timeout is swallowed by the catch below and the transport is
   * closed on the next line — the same ending, by a shorter route.
   *
   * Closing while a request is in flight sends no goodbye at all: the EXIT
   * goes through send(), whose exchange() refuses a second concurrent request
   * before transmitting, and the refusal lands in the catch below. The
   * session still ends and the transport is still closed. No behaviour is
   * being described here that could be otherwise — awaiting the in-flight
   * request first would mean close() blocking on the very deadline the caller
   * may be closing to escape.
   *
   * Never throwing rests on that catch, not on the `.catch` after it: neither
   * transport's close() rejects over a socket that is still ours to close.
   * `test/session/session.spec.ts` "closes without throwing when the
   * transport underneath it is already dead" pins both transports.
   */
  async close() {
    if (!this.open_) return;
    if (this.subscribed_) return this.abandon();
    this.open_ = false;
    try {
      await this.send(CMD.EXIT);
    } catch {
    }
    await this.transport.close().catch(() => {
    });
  }
};
async function readTransfer(session, expected, first) {
  const chunks = [];
  let received = 0;
  let pending = first ?? null;
  const next = async () => {
    if (pending) {
      const p = pending;
      pending = null;
      return p;
    }
    return session.receiveMore();
  };
  const opening = await next();
  if (opening.command !== CMD.PREPARE_DATA) pending = opening;
  let tail;
  for (; ; ) {
    const packet = await next();
    if (packet.command !== CMD.DATA) {
      tail = packet;
      break;
    }
    chunks.push(packet.data);
    received += packet.data.length;
  }
  if (received < expected) {
    throw new ZkProtocolError(
      `transfer ended after ${received} of ${expected} bytes with command ${tail.command}`
    );
  }
  if (received > expected) {
    throw new ZkProtocolError(`transfer delivered ${received} bytes, expected ${expected}`);
  }
  if (tail.command !== CMD.ACK_OK) {
    throw new ZkProtocolError(`expected ACK_OK to close the transfer, got ${tail.command}`);
  }
  return Buffer.concat(chunks);
}
async function readBulkLegacy(session, command) {
  const res = await session.execute(command);
  if (res.command === CMD.ACK_DATA) {
    await freeBuffer(session);
    return res.data;
  }
  if (res.command !== CMD.PREPARE_DATA) {
    throw new ZkProtocolError(
      `expected ACK_DATA or PREPARE_DATA for command ${command}, got ${res.command}`,
      res.data
    );
  }
  if (res.data.length < 4) {
    throw new ZkProtocolError("PREPARE_DATA did not carry a size", res.data);
  }
  const declared = res.data.readUInt32LE(0);
  const body = await readTransfer(session, declared);
  await freeBuffer(session);
  return body;
}
async function freeBuffer(session) {
  try {
    await session.execute(CMD.FREE_DATA);
  } catch (err) {
    if (err instanceof ZkProtocolError || err instanceof ZkAuthError) return;
    throw err;
  }
}
async function readBulkBuffered(session, command, maxChunk) {
  const request = Buffer.alloc(11);
  request.writeUInt8(1, 0);
  request.writeUInt16LE(command, 1);
  request.writeUInt32LE(BUFFER_FCT[command] ?? 0, 3);
  request.writeUInt32LE(0, 7);
  const prepared = await session.tryExecute(CMD.PREPARE_BUFFER, request);
  if (prepared.command === CMD.ACK_ERROR) return null;
  if (prepared.command === CMD.ACK_UNAUTH) {
    throw unauthorizedReply(CMD.PREPARE_BUFFER, prepared.data);
  }
  if (prepared.command === CMD.DATA) {
    await freeBuffer(session);
    return prepared.data;
  }
  if (prepared.data.length < 5) {
    throw new ZkProtocolError("PREPARE_BUFFER did not report a size", prepared.data);
  }
  const total = prepared.data.readUInt32LE(1);
  const chunks = [];
  let offset = 0;
  while (offset < total) {
    const want = Math.min(maxChunk, total - offset);
    const req = Buffer.alloc(8);
    req.writeUInt32LE(offset, 0);
    req.writeUInt32LE(want, 4);
    const opening = await session.execute(CMD.READ_BUFFER, req);
    const chunk = await readTransfer(session, want, opening);
    chunks.push(chunk);
    offset += chunk.length;
  }
  await freeBuffer(session);
  return Buffer.concat(chunks);
}
async function readBulk(session, command, transport) {
  const buffered = await readBulkBuffered(session, command, MAX_CHUNK[transport]);
  if (buffered !== null) return buffered;
  return readBulkLegacy(session, command);
}
var FREE_SIZES_OFFSET = {
  userCount: 16,
  recordCount: 32,
  recordCapacity: 64
};
var REQUIRED_LENGTH = FREE_SIZES_OFFSET.recordCapacity + 4;
async function getInfo(session) {
  const res = await session.execute(CMD.GET_FREE_SIZES);
  if (res.data.length < REQUIRED_LENGTH) {
    throw new ZkProtocolError(
      `CMD_GET_FREE_SIZES reply is ${res.data.length} bytes, need at least ${REQUIRED_LENGTH}`,
      res.data
    );
  }
  return {
    userCount: res.data.readUInt32LE(FREE_SIZES_OFFSET.userCount),
    recordCount: res.data.readUInt32LE(FREE_SIZES_OFFSET.recordCount),
    recordCapacity: res.data.readUInt32LE(FREE_SIZES_OFFSET.recordCapacity)
  };
}
var USER_RECORD_SIZE = 72;
var ALTERNATE_USER_RECORD_SIZE = 28;
var AMBIGUOUS_USER_BODY_MODULUS = 504;
function decodeOne2(rec) {
  const hasPassword = readNulTerminated(rec, 3, 8).length > 0;
  const rawBuffer = Buffer.from(rec);
  rawBuffer.fill(0, 3, 11);
  return {
    uid: rec.readUInt16LE(0),
    privilege: rec.readUInt8(2),
    hasPassword,
    name: readNulTerminated(rec, 11, 24),
    cardNumber: rec.readUInt32LE(35),
    // Nine bytes, per zkteco-js helper/utils.js:143-144 (`slice(48, 48 + 9)`).
    // Eight, before v0.5, truncated a nine-digit id into a different identity.
    // PROVENANCE.md §User record width and size.
    userId: readNulTerminated(rec, 48, 9),
    raw: rawBuffer.toString("hex")
  };
}
function detectUserRecordSize(bodyLength, userCount) {
  if (userCount !== null && (!Number.isInteger(userCount) || userCount < 0)) {
    throw new ZkFramingError(`user count must be a non-negative integer, got ${userCount}`);
  }
  if (bodyLength === 0) {
    if (userCount === null || userCount === 0) return USER_RECORD_SIZE;
    throw new ZkFramingError(`user count is ${userCount} but the body is empty`);
  }
  if (userCount === null) {
    if (bodyLength % USER_RECORD_SIZE !== 0) {
      throw new ZkFramingError(
        `user body of ${bodyLength} bytes is not a multiple of ${USER_RECORD_SIZE}`
      );
    }
    if (bodyLength % AMBIGUOUS_USER_BODY_MODULUS === 0) {
      throw new ZkFramingError(
        `user body of ${bodyLength} bytes is undecidable without a user count: ${bodyLength / USER_RECORD_SIZE} record(s) of ${USER_RECORD_SIZE} bytes, or ${bodyLength / ALTERNATE_USER_RECORD_SIZE} of ${ALTERNATE_USER_RECORD_SIZE}. This library decodes only ${USER_RECORD_SIZE}-byte user records, and CMD_GET_FREE_SIZES supplied no count to settle it.`
      );
    }
    return USER_RECORD_SIZE;
  }
  if (userCount === 0) {
    throw new ZkFramingError(
      `user count is 0 but the body carries ${bodyLength} bytes; the count and the body contradict each other. FREE_SIZES_OFFSET is unverified, so a wrong userCount offset looks exactly like this.`
    );
  }
  if (bodyLength % userCount !== 0) {
    throw new ZkFramingError(
      `user body of ${bodyLength} bytes does not divide evenly by ${userCount} user(s)`
    );
  }
  const size = bodyLength / userCount;
  if (size === ALTERNATE_USER_RECORD_SIZE) {
    throw new ZkFramingError(
      `user body of ${bodyLength} bytes over a count of ${userCount} implies ${ALTERNATE_USER_RECORD_SIZE}-byte user records. This library decodes only ${USER_RECORD_SIZE}-byte records and will not guess at the ${ALTERNATE_USER_RECORD_SIZE}-byte dialect.`
    );
  }
  if (size !== USER_RECORD_SIZE) {
    throw new ZkFramingError(
      `user body of ${bodyLength} bytes over a count of ${userCount} implies ${size}-byte user records, which is neither ${USER_RECORD_SIZE} nor the ${ALTERNATE_USER_RECORD_SIZE}-byte dialect this library refuses.`
    );
  }
  return USER_RECORD_SIZE;
}
function parseUserData(data, userCount) {
  if (data.length < 4) {
    throw new ZkFramingError("user payload too short to hold its size header", data);
  }
  const totalSize = data.readUInt32LE(0);
  if (data.length < 4 + totalSize) {
    throw new ZkFramingError(
      `user payload declares ${totalSize} bytes but only ${data.length - 4} arrived`,
      data.subarray(0, 16)
    );
  }
  const body = data.subarray(4, 4 + totalSize);
  const size = detectUserRecordSize(body.length, userCount);
  const out = [];
  for (let off = 0; off + size <= body.length; off += size) {
    out.push(decodeOne2(body.subarray(off, off + size)));
  }
  return out;
}
async function readUserStream(session, transport) {
  return readBulk(session, CMD.USERTEMP_RRQ, transport);
}
async function getUsers(session, transport, userCount) {
  const stream = await readUserStream(session, transport);
  return parseUserData(stream, userCount);
}
function isAtOrAfter(a, boundary) {
  return a.local >= boundary.local;
}
function resolve(record, byUid, byNumericUserId) {
  if (record.userIdFromRecord !== null) {
    return { userId: record.userIdFromRecord, userIdSource: "device" };
  }
  const match = record.uid !== null ? byUid.get(record.uid) : record.numericUserId !== null ? byNumericUserId.get(record.numericUserId) : void 0;
  if (!match || match.userId === "") return { userId: null, userIdSource: null };
  return { userId: match.userId, userIdSource: "lookup" };
}
async function getAttendanceLogs(session, transport, opts = {}) {
  const { recordCount } = await getInfo(session);
  if (recordCount === 0) return [];
  const stream = await readBulk(session, CMD.ATTLOG_RRQ, transport);
  const after = await getInfo(session);
  if (after.recordCount !== recordCount) {
    throw new ZkFramingError(
      `the attendance buffer changed during the read: ${recordCount} record(s) before, ${after.recordCount} after`
    );
  }
  const records = parseAttendanceData(stream, recordCount);
  const needsLookup = opts.resolveUserIds !== false && records.some((r) => r.userIdFromRecord === null);
  const users = needsLookup ? await getUsers(session, transport, after.userCount) : [];
  const byUid = new Map(users.map((u) => [u.uid, u]));
  const byNumericUserId = /* @__PURE__ */ new Map();
  for (const u of users) {
    if (!/^\d+$/.test(u.userId)) continue;
    const n = Number(u.userId);
    byNumericUserId.set(n, byNumericUserId.has(n) ? null : u);
  }
  const logs = records.map((r) => ({
    ...resolve(r, byUid, byNumericUserId),
    uid: r.uid,
    timestamp: r.timestamp,
    status: r.status,
    verifyMode: r.verifyMode,
    recordSize: r.recordSize,
    raw: r.raw
  }));
  const since = opts.since;
  return since ? logs.filter((l) => isAtOrAfter(l.timestamp, since)) : logs;
}
var DEVICE_PARAM = {
  SERIAL_NUMBER: "~SerialNumber",
  DEVICE_NAME: "~DeviceName",
  PLATFORM: "~Platform",
  OS: "~OS",
  FP_VERSION: "~ZKFPVersion",
  VENDOR: "~OEMVendor",
  PRODUCT_TIME: "~ProductTime",
  PIN_WIDTH: "~PIN2Width",
  SSR: "~SSR",
  MAC: "MAC",
  WORK_CODE: "WorkCode",
  FACE_ON: "FaceFunOn"
};
function encodeParamRequest(keyword) {
  if (keyword.length === 0) {
    throw new RangeError("parameter keyword must not be empty");
  }
  if (keyword.includes("=") || keyword.includes("\0")) {
    throw new RangeError(
      `parameter keyword must not contain '=' or NUL, got ${JSON.stringify(keyword)}`
    );
  }
  for (let i = 0; i < keyword.length; i++) {
    if (keyword.charCodeAt(i) > 255) {
      throw new RangeError(
        `parameter keyword must be representable in latin1 (byte values 0-255), got ${JSON.stringify(keyword)}`
      );
    }
  }
  return Buffer.from(`${keyword}\0`, "latin1");
}
function decodeParamReply(keyword, body) {
  const text = readNulTerminated(body, 0, body.length);
  const sep = text.indexOf("=");
  if (sep === -1) {
    throw new ZkProtocolError(
      `CMD_OPTIONS_RRQ reply for ${keyword} carries no '=' separator`,
      body
    );
  }
  const echoed = text.slice(0, sep);
  if (echoed !== keyword) {
    throw new ZkProtocolError(
      `CMD_OPTIONS_RRQ reply echoes ${echoed} but ${keyword} was requested`,
      body
    );
  }
  return text.slice(sep + 1);
}
async function getParameters(session, keys) {
  const out = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    const res = await session.tryExecute(CMD.OPTIONS_RRQ, encodeParamRequest(key));
    if (res.command === CMD.ACK_ERROR) continue;
    if (res.command === CMD.ACK_UNAUTH) {
      throw new ZkAuthError(`CMD_OPTIONS_RRQ for ${key} answered ACK_UNAUTH`, res.data);
    }
    out[key] = decodeParamReply(key, res.data);
  }
  return out;
}
var IDENTITY_KEYS = {
  serialNumber: DEVICE_PARAM.SERIAL_NUMBER,
  deviceName: DEVICE_PARAM.DEVICE_NAME,
  platform: DEVICE_PARAM.PLATFORM,
  os: DEVICE_PARAM.OS
};
async function readFirmware(session) {
  const res = await session.tryExecute(CMD.GET_VERSION);
  if (res.command === CMD.ACK_ERROR) return null;
  if (res.command === CMD.ACK_UNAUTH) {
    throw new ZkAuthError("CMD_GET_VERSION answered ACK_UNAUTH", res.data);
  }
  return readNulTerminated(res.data, 0, res.data.length);
}
async function getIdentity(session) {
  const params = await getParameters(session, Object.values(IDENTITY_KEYS));
  const firmwareVersion = await readFirmware(session);
  return {
    serialNumber: params[IDENTITY_KEYS.serialNumber] ?? null,
    deviceName: params[IDENTITY_KEYS.deviceName] ?? null,
    platform: params[IDENTITY_KEYS.platform] ?? null,
    os: params[IDENTITY_KEYS.os] ?? null,
    firmwareVersion
  };
}
async function getTime(session) {
  const res = await session.execute(CMD.GET_TIME);
  if (res.data.length < 4) {
    throw new ZkProtocolError(
      `CMD_GET_TIME reply is ${res.data.length} bytes, need at least 4`,
      res.data
    );
  }
  return decodeZkTime(res.data.readUInt32LE(0));
}
var DEFAULT_BUFFER_LIMIT = 256;
var Subscription = class {
  constructor(session, opts) {
    this.session = session;
    this.opts = opts;
  }
  session;
  opts;
  queue = [];
  /**
   * One state, not five flags. Before v0.5 `waiter`, `rejectWaiter`,
   * `failure`, `ended` and `closed` had to be kept in step by hand at four
   * sites, and the type let them disagree (spec v0.5 §8).
   */
  state = { kind: "registering" };
  pending = null;
  idleTimer = null;
  /**
   * Registration completed: the stream is live and the idle timer starts.
   *
   * Called by ZkDevice.subscribe after Session.subscribe resolves. Arming
   * the timer in the constructor, as before v0.5, started it before
   * CMD_REG_EVENT was even sent, so an idleTimeoutMs shorter than the
   * registration round trip returned a stream that had already ended.
   */
  start() {
    if (this.state.kind !== "registering") return;
    this.state = { kind: "live" };
    this.armIdleTimer();
  }
  /** Accepts one packet the transport pushed. Never throws. */
  push(pkt) {
    if (this.state.kind === "failed" || this.state.kind === "closed") return;
    if (!isEventPacket(pkt)) {
      this.fail(
        new ZkProtocolError(
          `a non-event packet (command ${pkt.command}) arrived on a listening connection`
        )
      );
      return;
    }
    if (this.state.kind === "live") this.armIdleTimer();
    const event = decodeRealtimeEvent(pkt);
    const pending = this.takePending();
    if (pending) {
      pending.resolve({ value: event, done: false });
      return;
    }
    this.queue.push(event);
    if (this.queue.length > this.opts.bufferLimit) {
      this.fail(
        new ZkProtocolError(
          `event buffer of ${this.opts.bufferLimit} overflowed; the consumer is not keeping up`
        )
      );
    }
  }
  /**
   * Ends the stream with an error.
   *
   * Events already queued are still delivered first — losing readings that
   * arrived intact, because the connection died afterwards, would be worse
   * than reporting the failure a few iterations later.
   */
  fail(err) {
    if (this.state.kind === "failed" || this.state.kind === "closed") return;
    this.state = { kind: "failed", error: err };
    this.clearIdleTimer();
    if (this.queue.length === 0) {
      this.takePending()?.reject(err);
    }
  }
  [Symbol.asyncIterator]() {
    return {
      next: () => {
        const queued = this.queue.shift();
        if (queued) return Promise.resolve({ value: queued, done: false });
        switch (this.state.kind) {
          case "failed":
            return Promise.reject(this.state.error);
          case "closed":
            return this.state.error ? Promise.reject(this.state.error) : Promise.resolve({ value: void 0, done: true });
          case "registering":
          case "live":
            break;
          default: {
            const exhaustive = this.state;
            throw new Error(`unreachable state ${String(exhaustive)}`);
          }
        }
        if (this.pending) {
          return Promise.reject(
            new ZkConnectionError(
              "a next() is already pending; this stream does not support concurrent iteration"
            )
          );
        }
        return new Promise((resolve2, reject) => {
          this.pending = { resolve: resolve2, reject };
        });
      },
      /**
       * Called by `for await` when the consumer leaves the loop early — a
       * break, a return, or an exception raised in the loop BODY. Without it,
       * the obvious consumer loop (take a few events, then break) leaves the
       * subscription registered and the socket under it open, with the device
       * still pushing events to nobody.
       *
       * Ending the stream here means ending the connection it rides on, and
       * that is the right scope rather than an overreach: this stream does not
       * reconnect and a device buffers nothing for a subscriber that went
       * away, so there is no resumable state to preserve. close() is
       * idempotent, so a consumer that breaks and then calls close() anyway
       * pays nothing.
       *
       * A rejection from next() does NOT route here — the language calls
       * return() only for an early exit from a loop that is otherwise healthy.
       * That is correct: fail() has already ended the stream by then.
       *
       * No throw(). `for await` never calls it; only explicit generator
       * delegation does, and this iterator is not written by a generator.
       */
      return: async () => {
        await this.close();
        return { value: void 0, done: true };
      }
    };
  }
  /**
   * Ends the subscription and the connection it rides on. Idempotent.
   *
   * A stream that already failed stays failed: the error survives into the
   * closed state (see `State`) rather than being dropped in favour of a
   * clean `done: true`, and a pending waiter is rejected with it rather than
   * resolved.
   */
  async close() {
    if (this.state.kind === "closed") return;
    const error = this.state.kind === "failed" ? this.state.error : void 0;
    this.state = error ? { kind: "closed", error } : { kind: "closed" };
    this.clearIdleTimer();
    const pending = this.takePending();
    if (pending) {
      if (error) pending.reject(error);
      else pending.resolve({ value: void 0, done: true });
    }
    await this.session.close();
  }
  takePending() {
    const pending = this.pending;
    this.pending = null;
    return pending;
  }
  armIdleTimer() {
    if (this.opts.idleTimeoutMs <= 0) return;
    this.clearIdleTimer();
    this.idleTimer = setTimeout(() => {
      this.fail(new ZkTimeoutError(`no event within ${this.opts.idleTimeoutMs}ms`));
    }, this.opts.idleTimeoutMs);
    this.idleTimer.unref();
  }
  clearIdleTimer() {
    if (this.idleTimer) {
      clearTimeout(this.idleTimer);
      this.idleTimer = null;
    }
  }
};
var START_MARKER = Buffer.from([80, 80, 130, 125]);
var TCP_PREFIX_SIZE = 8;
var MAX_DECLARED_SIZE = MAX_CHUNK.tcp + 8;
function frameTcp(payload) {
  const head = Buffer.alloc(TCP_PREFIX_SIZE);
  START_MARKER.copy(head, 0);
  head.writeUInt32LE(payload.length, 4);
  return Buffer.concat([head, payload]);
}
function tryUnframeTcp(buf) {
  if (buf.length < TCP_PREFIX_SIZE) return null;
  if (!buf.subarray(0, 4).equals(START_MARKER)) {
    throw new ZkFramingError("TCP start marker mismatch", buf.subarray(0, 8));
  }
  const size = buf.readUInt32LE(4);
  if (size > MAX_DECLARED_SIZE) {
    throw new ZkFramingError(
      `TCP declared payload size ${size} exceeds the ${MAX_DECLARED_SIZE}-byte maximum`,
      buf.subarray(0, 8)
    );
  }
  if (buf.length < TCP_PREFIX_SIZE + size) return null;
  return {
    payload: Buffer.from(buf.subarray(TCP_PREFIX_SIZE, TCP_PREFIX_SIZE + size)),
    consumed: TCP_PREFIX_SIZE + size
  };
}
var PacketInbox = class {
  queue = [];
  pending = null;
  listener = null;
  get listening() {
    return this.listener !== null;
  }
  /** A complete payload arrived: listener first, then a pending receive, then the queue. */
  deliver(payload) {
    if (this.listener) {
      this.listener.onPacket(payload);
      return;
    }
    const pending = this.takePending();
    if (pending) {
      pending.resolve(payload);
      return;
    }
    this.queue.push(payload);
  }
  receive(timeoutMs, held) {
    if (this.listener) {
      return Promise.reject(
        new ZkConnectionError("this transport is listening for events; receive() is not available")
      );
    }
    if (this.pending) {
      return Promise.reject(
        new ZkConnectionError(
          "a receive() is already pending; this transport does not support concurrent receives"
        )
      );
    }
    const queued = this.queue.shift();
    if (queued) return Promise.resolve(queued);
    const failure = held();
    if (failure) return Promise.reject(failure);
    return new Promise((resolve2, reject) => {
      const timer = setTimeout(() => {
        this.pending = null;
        reject(new ZkTimeoutError(`no reply within ${timeoutMs}ms`));
      }, timeoutMs);
      this.pending = { resolve: resolve2, reject, timer };
    });
  }
  listen(onPacket, onError, held) {
    if (this.listener) throw new ZkConnectionError("this transport is already listening");
    if (this.pending) throw new ZkConnectionError("cannot listen while a receive() is pending");
    this.listener = { onPacket, onError };
    const queued = this.queue;
    this.queue = [];
    for (const payload of queued) onPacket(payload);
    const failure = held();
    if (failure) onError(failure);
  }
  /** Tells whoever is waiting. Returns whether anyone was. */
  notify(err) {
    const pending = this.takePending();
    if (pending) {
      pending.reject(err);
      return true;
    }
    if (this.listener) {
      this.listener.onError(err);
      return true;
    }
    return false;
  }
  /** Rejects a pending receive, if any. For close(). */
  settle(err) {
    const pending = this.takePending();
    if (pending) pending.reject(err);
  }
  /** Drops queued payloads. For a framing failure, after which nothing queued belongs to a live exchange. */
  clear() {
    this.queue = [];
  }
  takePending() {
    const pending = this.pending;
    if (!pending) return null;
    this.pending = null;
    clearTimeout(pending.timer);
    return pending;
  }
};
var KEEPALIVE_DELAY_MS = 3e4;
var TcpTransport = class {
  constructor(opts) {
    this.opts = opts;
  }
  opts;
  socket = null;
  /** Bytes arrived but not yet consumed as complete packets. */
  buffered = Buffer.alloc(0);
  inbox = new PacketInbox();
  failure = null;
  connect(timeoutMs) {
    return new Promise((resolve2, reject) => {
      const sock = net.createConnection({ host: this.opts.host, port: this.opts.port });
      const where = `${this.opts.host}:${this.opts.port}`;
      const settle = (err) => {
        sock.destroy();
        reject(err);
      };
      const onError = (err) => settle(new ZkConnectionError(`cannot connect to ${where}: ${err.message}`));
      const onTimeout = () => settle(new ZkConnectionError(`cannot connect to ${where} within ${timeoutMs}ms`));
      sock.setTimeout(timeoutMs);
      sock.once("error", onError);
      sock.once("timeout", onTimeout);
      sock.once("connect", () => {
        sock.setTimeout(0);
        sock.off("error", onError);
        sock.off("timeout", onTimeout);
        this.socket = sock;
        sock.on("data", (chunk) => this.absorb(chunk));
        sock.on("error", (err) => this.fail(new ZkConnectionError(err.message)));
        sock.on("close", () => this.fail(new ZkConnectionError("connection closed by peer")));
        resolve2();
      });
    });
  }
  /**
   * TCP splits and coalesces freely, so bytes are accumulated and only
   * surfaced once the length prefix says a whole packet has arrived. Several
   * packets can emerge from one chunk.
   */
  absorb(chunk) {
    this.buffered = Buffer.concat([this.buffered, chunk]);
    for (; ; ) {
      let framed;
      try {
        framed = tryUnframeTcp(this.buffered);
      } catch (err) {
        this.buffered = Buffer.alloc(0);
        this.inbox.clear();
        this.fail(err);
        const sock = this.socket;
        this.socket = null;
        if (sock) {
          sock.removeAllListeners("close");
          sock.destroy();
        }
        return;
      }
      if (!framed) return;
      this.buffered = this.buffered.subarray(framed.consumed);
      this.inbox.deliver(framed.payload);
    }
  }
  /**
   * Records a socket failure and tells whoever is waiting on this transport.
   *
   * The failure is kept for the life of the object, deliberately, and this is
   * where TcpTransport and UdpTransport part company. A TCP failure means the
   * connection is gone — 'close' and 'error' both route here — so every later
   * receive() on this transport really is doomed, and answering each one with
   * the reason is the most useful thing it can do.
   *
   * UdpTransport forgets a failure once it has been delivered, because a UDP
   * socket has no connection to lose and cannot tell an error about one
   * datagram from an error about itself. See the decision rule on
   * UdpTransport.fail; the difference is a considered one, not drift.
   */
  fail(err) {
    this.failure ??= err;
    this.inbox.notify(err);
  }
  send(payload) {
    const sock = this.socket;
    if (!sock) {
      return Promise.reject(this.failure ?? new ZkConnectionError("transport is not connected"));
    }
    return new Promise((resolve2, reject) => {
      sock.write(
        frameTcp(payload),
        (err) => err ? reject(new ZkConnectionError(err.message)) : resolve2()
      );
    });
  }
  receive(timeoutMs) {
    return this.inbox.receive(timeoutMs, () => this.failure);
  }
  listen(onPacket, onError) {
    this.inbox.listen(onPacket, onError, () => this.failure);
    this.socket?.setKeepAlive(true, KEEPALIVE_DELAY_MS);
  }
  close() {
    this.inbox.settle(new ZkConnectionError("transport closed while a receive was pending"));
    const sock = this.socket;
    this.socket = null;
    if (!sock) return Promise.resolve();
    return new Promise((resolve2) => {
      sock.removeAllListeners("close");
      sock.end(() => {
        sock.destroy();
        resolve2();
      });
    });
  }
};
var UdpTransport = class {
  constructor(opts) {
    this.opts = opts;
  }
  opts;
  socket = null;
  inbox = new PacketInbox();
  failure = null;
  connect(timeoutMs) {
    return new Promise((resolve2, reject) => {
      const sock = dgram.createSocket("udp4");
      let connectSettled = false;
      const where = `${this.opts.host}:${this.opts.port}`;
      const timer = setTimeout(() => {
        if (connectSettled) return;
        connectSettled = true;
        sock.close();
        reject(new ZkConnectionError(`cannot connect to ${where} within ${timeoutMs}ms`));
      }, timeoutMs);
      sock.on("error", (err) => {
        const failure = new ZkConnectionError(err.message);
        if (connectSettled) {
          this.fail(failure);
          return;
        }
        connectSettled = true;
        clearTimeout(timer);
        sock.close();
        reject(failure);
      });
      sock.on("message", (msg) => this.inbox.deliver(Buffer.from(msg)));
      sock.bind(0, () => {
        if (connectSettled) return;
        sock.connect(this.opts.port, this.opts.host, (err) => {
          if (connectSettled) return;
          connectSettled = true;
          clearTimeout(timer);
          if (err) {
            sock.close();
            reject(new ZkConnectionError(`cannot connect to ${where}: ${err.message}`));
            return;
          }
          this.socket = sock;
          resolve2();
        });
      });
    });
  }
  /**
   * Reports a socket failure to whoever is waiting on this transport, or
   * holds it for the next consumer if nobody is waiting yet.
   *
   * DECISION RULE: a UDP socket failure is delivered to exactly one consumer
   * and is then forgotten. It is never replayed.
   *
   * The asymmetry with TcpTransport, which keeps its failure for the life of
   * the object, is the point. A TCP failure means the connection is gone, so
   * every later receive() really is doomed and repeating the reason is the
   * most useful thing the transport can do. UDP has no connection to lose: a
   * post-bind error can be about one datagram rather than about the socket,
   * and nothing here can tell those apart. On Windows an ICMP
   * port-unreachable is delivered as ECONNRESET even on an UNCONNECTED
   * socket, so a single datagram sent to a powered-down terminal used to end
   * this transport for the rest of its life. With the socket connected
   * (v0.5), an ICMP port-unreachable surfaces as an 'error' on every
   * platform, not only Windows; the rule is unchanged and now applies
   * uniformly.
   *
   * This does not hide a socket that really is dead. The next operation on it
   * raises a FRESH error, which is a more accurate report than a replayed
   * stale one. The cost is that a receive() issued between the clearing and
   * the next real error waits out its timeout instead of failing fast —
   * accepted, because at that moment this transport genuinely does not know
   * whether the socket is dead.
   *
   * That cost is now mostly hypothetical from a Session's point of view: a
   * ZkConnectionError reaching Session ends the session and closes this
   * transport (spec v0.5 §5.2), so nothing polls on after one. The rule is
   * kept because it is the transport's own contract, and its remaining
   * consumers are a direct transport user and the listen() path, which stays
   * attached after an error.
   *
   * At most one of the two consumers below can exist at a time: receive()
   * refuses while a listener is attached, and listen() refuses while a
   * receive() is pending. So delivering to the first one found is delivering
   * to the only one there is.
   *
   * The socket is deliberately not closed here, mirroring TcpTransport: the
   * owner closes it, and a transport that closed itself would turn a reported
   * failure back into a silent one for anything that looked afterwards.
   */
  fail(err) {
    if (this.inbox.notify(err)) return;
    this.failure = err;
  }
  /**
   * Takes the held failure, if there is one, clearing it as it goes.
   *
   * Reading and clearing are one operation on purpose — a caller that read it
   * without clearing would replay it, which is the behaviour the rule on
   * fail() exists to prevent.
   */
  takeFailure() {
    const err = this.failure;
    this.failure = null;
    return err;
  }
  send(payload) {
    const sock = this.socket;
    if (!sock) return Promise.reject(new ZkConnectionError("transport is not connected"));
    return new Promise((resolve2, reject) => {
      sock.send(payload, (err) => err ? reject(new ZkConnectionError(err.message)) : resolve2());
    });
  }
  receive(timeoutMs) {
    return this.inbox.receive(timeoutMs, () => this.takeFailure());
  }
  listen(onPacket, onError) {
    this.inbox.listen(onPacket, onError, () => this.takeFailure());
  }
  close() {
    this.inbox.settle(new ZkConnectionError("transport closed while a receive was pending"));
    const sock = this.socket;
    this.socket = null;
    if (!sock) return Promise.resolve();
    return new Promise((resolve2) => {
      sock.close(() => resolve2());
    });
  }
};
function createTransport(kind, opts) {
  return kind === "tcp" ? new TcpTransport(opts) : new UdpTransport(opts);
}
var ZkDevice = class {
  session = null;
  stream = null;
  connecting = null;
  host;
  port;
  transportKind;
  commKey;
  timeoutMs;
  constructor(opts) {
    this.host = opts.host;
    this.port = opts.port ?? 4370;
    this.transportKind = opts.transport ?? "tcp";
    this.commKey = opts.commKey ?? 0;
    this.timeoutMs = opts.timeoutMs ?? 5e3;
  }
  makeTransport() {
    return createTransport(this.transportKind, { host: this.host, port: this.port });
  }
  requireSession() {
    if (!this.session) throw new ZkConnectionError("not connected \u2014 call connect() first");
    return this.session;
  }
  /**
   * A session that can still answer requests.
   *
   * One ZkDevice owns one connection and is in exactly one mode. A consumer
   * that needs to poll and listen at once constructs two instances, which
   * makes "open a second connection to this device" a visible decision rather
   * than an assumption buried here — the number of concurrent connections a
   * device accepts has never been observed.
   */
  requireIdleSession() {
    const session = this.requireSession();
    if (session.subscribed) {
      throw new ZkConnectionError(
        "this device is subscribed to realtime events; close the stream, or use a separate ZkDevice to read"
      );
    }
    return session;
  }
  /**
   * Handshakes, authenticating with the comm key when the device asks.
   *
   * Safe to call again on an already-connected instance: any existing
   * subscription is ended and any existing session is closed first, so a
   * second connect() cannot leak the first socket, nor leave a caller's
   * earlier stream awaiting an event that will never arrive. Safe to call
   * again while a previous call — or any number of them — is still in
   * flight, too: every connect() chains on the one before it, so
   * overlapping calls run strictly in order and each closes what the
   * previous one opened rather than racing it or leaking it. A
   * disconnect() issued at any point during a connect() — including during
   * this cleanup — closes whatever that connect() opened rather than
   * letting it install after disconnect() has already returned.
   */
  async connect() {
    const prior = this.connecting;
    const opening = (async () => {
      if (prior) await prior.catch(() => {
      });
      await this.connectSequence();
    })();
    this.connecting = opening;
    try {
      await opening;
    } finally {
      if (this.connecting === opening) this.connecting = null;
    }
  }
  async connectSequence() {
    const stream = this.stream;
    this.stream = null;
    if (stream) await stream.close();
    if (this.session) {
      await this.session.close();
      this.session = null;
    }
    const session = new Session(this.makeTransport(), {
      timeoutMs: this.timeoutMs,
      commKey: this.commKey
    });
    await session.open();
    this.session = session;
  }
  async getInfo() {
    return getInfo(this.requireIdleSession());
  }
  /**
   * Reads what the device says about itself: serial number, name, platform,
   * OS and firmware version.
   *
   * Five sequential round trips. A field is `null` when the device REFUSED
   * that keyword — never when the read failed, which throws instead. Which
   * keywords a given firmware exposes is model-dependent and unverified.
   *
   * Named getIdentity rather than getDeviceInfo because ZkDeviceInfo already
   * means the storage counters that getInfo() returns.
   */
  async getIdentity() {
    return getIdentity(this.requireIdleSession());
  }
  /**
   * Reads named device parameters.
   *
   * A key the device refused is absent from the result; a key it answered
   * with no value is present as ''. Use DEVICE_PARAM for the keywords that
   * have been observed, or pass any string.
   *
   * Returns a null-prototype object, so `key in result` is correct even for a
   * key that collides with an Object.prototype member name (e.g. 'toString')
   * — a plain object would report `true` there via the prototype chain even
   * though the device never answered. The cost: `result.hasOwnProperty(key)`
   * throws, because there is no `hasOwnProperty` on the prototype chain to
   * call. Use `key in result`, or `Object.hasOwn(result, key)`.
   */
  async getParameters(keys) {
    return getParameters(this.requireIdleSession(), keys);
  }
  /**
   * Reads the device's own clock, as naive local time with no offset.
   *
   * Useful mainly for detecting drift: a device whose clock has slipped
   * produces attendance timestamps that look wrong for no visible reason.
   * Setting the clock is a write path and is deliberately not implemented.
   */
  async getTime() {
    return getTime(this.requireIdleSession());
  }
  /**
   * Reads the enrolled user list.
   *
   * The list is transferred FIRST and the device's user count asked for
   * afterwards, even though the count is what decides the record width
   * (codec/records/user.ts). The count is what lets a legitimate 72-byte
   * device with a multiple of seven users be read at all, since 7 x 72 and
   * 18 x 28 are the same 504 bytes — but asking for it first meant a device
   * that would not answer CMD_GET_FREE_SIZES lost the user list too, because
   * the failed count had already taken the session down. Bytes in hand cannot
   * be lost to a count that never arrives.
   *
   * `getAttendanceLogs` is NOT the same shape, though an earlier draft of this
   * comment said it was: it reads the count before its own transfer and again
   * after, and the value it hands to getUsers is read before the USER transfer,
   * not after it. It also has no swallow — a failed getInfo aborts the whole
   * call — so it offers no degradation guarantee to compare against. The
   * ordering below is this method's own.
   */
  async getUsers() {
    const session = this.requireIdleSession();
    const stream = await readUserStream(session, this.transportKind);
    let userCount = null;
    try {
      userCount = (await getInfo(session)).userCount;
    } catch (err) {
      if (!(err instanceof ZkError)) throw err;
      userCount = null;
    }
    return parseUserData(stream, userCount);
  }
  /**
   * Reads the attendance log.
   *
   * The device is never disabled first. Many implementations send
   * CMD_DISABLEDEVICE before a bulk read so the buffer cannot shift
   * mid-transfer; on a polling schedule that locks employees out of badging
   * every cycle. The interleaved-write risk is met by reading the record
   * count on both sides of the transfer and refusing if it moved; the
   * framing guard on its own cannot see a count that is stale by a divisor.
   */
  async getAttendanceLogs(opts) {
    return getAttendanceLogs(this.requireIdleSession(), this.transportKind, opts);
  }
  /**
   * Subscribes to the events the device pushes.
   *
   * The stream does not reconnect and does not backfill: realtime complements
   * polling rather than replacing it, so a dropped connection ends the stream
   * loudly and the next poll recovers whatever was missed.
   *
   * While subscribed this device answers no read commands. Closing the stream
   * closes the connection; call connect() again to read.
   *
   * Always close the stream — `try { for await ... } finally { close() }`.
   * That includes the error path: a stream that ended with an error stops
   * delivering but does NOT release the connection, which stays open with a
   * listener attached until close() or disconnect() is called.
   */
  async subscribe(opts) {
    const session = this.requireIdleSession();
    const resolved = {
      events: opts?.events ?? EVENT_FLAG.ATTENDANCE,
      bufferLimit: opts?.bufferLimit ?? DEFAULT_BUFFER_LIMIT,
      idleTimeoutMs: opts?.idleTimeoutMs ?? 0
    };
    if (!Number.isFinite(resolved.bufferLimit) || resolved.bufferLimit <= 0) {
      throw new RangeError(`bufferLimit must be a positive number, got ${String(opts?.bufferLimit)}`);
    }
    if (!Number.isFinite(resolved.idleTimeoutMs) || resolved.idleTimeoutMs < 0) {
      throw new RangeError(
        `idleTimeoutMs must be a non-negative number, got ${String(opts?.idleTimeoutMs)}`
      );
    }
    const subscription = new Subscription(session, resolved);
    await session.subscribe(
      resolved.events,
      (pkt) => subscription.push(pkt),
      (err) => subscription.fail(err)
    );
    subscription.start();
    this.stream = subscription;
    return subscription;
  }
  /** Closes the session. Safe to call twice, before connect(), and during it. */
  async disconnect() {
    const connecting = this.connecting;
    if (connecting) await connecting.catch(() => {
    });
    const stream = this.stream;
    this.stream = null;
    if (stream) await stream.close();
    const session = this.session;
    this.session = null;
    if (session) await session.close();
  }
};

// tools/attendance-find.mjs
var execFileAsync = promisify(execFile);
var PORT = Number(process.env.RJ_DEVICE_PORT || 4370);
var COMM_KEY = Number(process.env.RJ_COMM_KEY || 0);
var CONFIGURED_IP = process.env.RJ_DEVICE_IP || "";
var ZK_OUI = ["0017 61", "00:17:61", "00-17-61"];
var ok = (text) => console.log(`  \x1B[32m/\x1B[0m ${text}`);
var warn = (text) => console.log(`  \x1B[33m!\x1B[0m ${text}`);
var info = (text) => console.log(`    ${text}`);
function localSubnets() {
  const out = [];
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (entry.family !== "IPv4" || entry.internal) continue;
      if (entry.netmask !== "255.255.255.0") continue;
      out.push({ address: entry.address, prefix: entry.address.split(".").slice(0, 3).join(".") });
    }
  }
  return out;
}
function probe(host, timeoutMs) {
  return new Promise((resolve2) => {
    const socket = net2.connect({ host, port: PORT });
    const done = (value) => {
      socket.destroy();
      resolve2(value);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false));
    socket.once("error", () => done(false));
  });
}
async function arpTable() {
  try {
    const { stdout } = await execFileAsync("arp", ["-a"]);
    return stdout;
  } catch {
    return "";
  }
}
function macOf(arp2, ip) {
  const line = arp2.split(/\r?\n/).find((row) => new RegExp(`\\b${ip.replace(/\./g, "\\.")}\\b`).test(row));
  const match = line?.match(/([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i);
  return match ? match[0] : null;
}
var subnets = localSubnets();
if (subnets.length === 0) {
  console.error("Khong thay card mang IPv4 /24 nao dang hoat dong.");
  process.exit(1);
}
console.log(`
\x1B[1mQuet cong ${PORT} tren ${subnets.length} dai mang\x1B[0m`);
for (const subnet of subnets) info(`${subnet.prefix}.0/24  (may nay: ${subnet.address})`);
var hits = [];
for (const subnet of subnets) {
  const results = await Promise.all(
    Array.from({ length: 254 }, (_, index) => {
      const host = `${subnet.prefix}.${index + 1}`;
      return probe(host, 2500).then((open) => open ? host : null);
    })
  );
  hits.push(...results.filter(Boolean));
}
console.log("");
if (hits.length === 0) {
  warn(`Khong host nao mo cong ${PORT}.`);
  info("May cham cong dang tat, rut dien, rut day mang, hoac o dai mang khac.");
  info("Kiem tra den tin hieu o cong mang sau may va bieu tuong mang tren man hinh may.");
  process.exit(1);
}
var arp = await arpTable();
var found = [];
for (const host of hits) {
  const mac = macOf(arp, host);
  const isZk = mac ? ZK_OUI.some((oui) => mac.toLowerCase().startsWith(oui.toLowerCase().slice(0, 8))) : false;
  const device2 = new ZkDevice({ host, port: PORT, commKey: COMM_KEY, timeoutMs: 8e3 });
  let label = "mo cong nhung khong bat tay duoc (co the khong phai may cham cong)";
  let confirmed = false;
  try {
    await device2.connect();
    const identity = await device2.getIdentity();
    const counts = await device2.getInfo();
    label = `serial ${identity.serialNumber ?? "?"} | ${counts.userCount} nguoi | ${counts.recordCount} ban ghi`;
    confirmed = true;
  } catch (error) {
    if (error instanceof ZkAuthError) {
      label = "la may ZKTeco nhung comm key dang dung bi tu choi";
      confirmed = true;
    }
  } finally {
    await device2.disconnect().catch(() => void 0);
  }
  found.push({ host, mac, isZk, confirmed, label });
  const mark = confirmed ? ok : warn;
  mark(`${host}${mac ? `  (MAC ${mac}${isZk ? ", ZKTeco" : ""})` : ""}`);
  info(label);
}
var device = found.find((item) => item.confirmed) || found[0];
console.log("");
if (!device.confirmed) {
  warn("Khong xac nhan duoc may cham cong nao.");
  process.exit(1);
}
if (CONFIGURED_IP && CONFIGURED_IP !== device.host) {
  warn(`.env.attendance-bridge dang tro toi ${CONFIGURED_IP}, nhung may thuc o ${device.host}.`);
  info(`Sua RJ_DEVICE_IP thanh ${device.host}, roi dat IP tinh tren may de khoi troi lan nua.`);
} else if (CONFIGURED_IP) {
  ok(`Khop .env.attendance-bridge (RJ_DEVICE_IP = ${CONFIGURED_IP}).`);
} else {
  info(`Dat RJ_DEVICE_IP = ${device.host} trong .env.attendance-bridge.`);
}
